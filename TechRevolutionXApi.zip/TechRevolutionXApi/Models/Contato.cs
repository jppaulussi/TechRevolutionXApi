﻿namespace TechRevolutionXApi.Models
{
    public class Contato
    {
    }
}
