﻿using System.Data;
using TechRevolutionXApi.Interfaces;
using TechRevolutionXApi.Models;
using Dapper;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace TechRevolutionXApi.Repository
{
    public class CadastroRepository : IContatoRepository
    {
        private readonly IDbConnection _context;
        
        public CadastroRepository(IDbConnection context) {
            _context = context;

    }

        public async Task<IList<Contato>> GetAllAsync()
        {
            var resultado = await _context.GetAllAsync<Contato>();
            return resultado.ToList();
        }

        public async Task CreateAsync(Contato contato)
        {
            var comandoSql = @"INSERT INTO Contatos(""Nome"", ""Telefone"", ""Email"", ""DDD"")
                              VALUES (@Nome, @Telefone,@Email, @DDD)";

            await _context.ExecuteAsync(comandoSql, contato);

        }


    }
